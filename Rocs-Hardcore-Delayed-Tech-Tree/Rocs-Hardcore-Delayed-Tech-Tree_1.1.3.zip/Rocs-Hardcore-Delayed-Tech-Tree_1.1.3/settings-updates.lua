data:extend({
	{
		type = "bool-setting",
		name = "rocs-hardcore-push-back-repair-pack",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "rocs-hardcore-push-back-logistic-system",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "rocs-hardcore-push-back-cliff-explosives",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "rocs-hardcore-push-back-kovarex-nuclear-fuel-and-atomic-bomb",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "rocs-hardcore-z-infinite-tech-needs-cryogenic",
		setting_type = "startup",
		default_value = false,
	},
	{
		type = "bool-setting",
		name = "rocs-hardcore-push-back-night-vision-equipment",
		setting_type = "startup",
		default_value = true,
	},
})
