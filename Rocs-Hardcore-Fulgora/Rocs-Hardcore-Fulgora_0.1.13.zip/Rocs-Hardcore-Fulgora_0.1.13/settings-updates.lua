data:extend({
	{
		type = "bool-setting",
		name = "rocs-hardcore-fulgora-lightning-rods-need-research",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "rocs-hardcore-fulgora-increase-oil-walking-speed",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "rocs-hardcore-fulgora-make-ruins-placeable",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "rocs-hardcore-fulgora-make-ruin-attractors-generate-power",
		setting_type = "startup",
		default_value = true,
	},
})
