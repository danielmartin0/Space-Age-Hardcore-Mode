require("scripts.main")
